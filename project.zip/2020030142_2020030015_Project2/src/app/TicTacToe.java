package app;

import control.GameController;

public class TicTacToe {
	
	public static void main(String[] args) {		
		GameController gc = new GameController();
		gc.start();
	}
}